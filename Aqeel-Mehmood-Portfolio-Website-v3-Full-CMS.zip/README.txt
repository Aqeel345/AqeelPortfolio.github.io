AQEEL MEHMOOD PORTFOLIO V3 — FULL CONNECTED CMS DEMO

Public site: index.html
Admin: admin.html

Login:
Username: admin
Password: Aqeel@2026

Admin can manage:
Home, About, Services, Portfolio projects, project thumbnails/links,
Achievements, Testimonials, Contact email/TikTok/contact text,
Profile image, and the global color theme.

IMPORTANT:
This build uses browser localStorage/sessionStorage so the Admin Panel and public pages are actually connected in the same browser.
A production website needs a secure server-side authentication system and database for central multi-device storage. Change the demo credentials before publishing.
