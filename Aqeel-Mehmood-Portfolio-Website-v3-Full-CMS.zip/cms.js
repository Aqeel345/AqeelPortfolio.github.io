(function(){
const KEY="aqeelCMS_v3";
const defaults={
site:{name:"Aqeel Mehmood",title:"Web Developer | 2D Animator | Graphic Designer",email:"your-email@example.com",tiktok:"",profileImage:"",theme:"midnight"},
home:{kicker:"AVAILABLE FOR CREATIVE PROJECTS",headline:"Ideas into digital experiences.",description:"I'm Aqeel Mehmood — a Web Developer, 2D Animator and Graphic Designer creating modern websites, engaging animations and visual identities.",stats:[["2+","Years Experience"],["10+","Projects"],["2","Real Clients"]]},
about:{headline:"Creative mind. Digital builder.",intro:"I'm Aqeel Mehmood, a Web Developer, 2D Animator and Graphic Designer with around 2 years of experience and a practical, creative approach to digital work.",mindset:"Creative. Professional. Hardworking. Fast learner.",story1:"My work sits at the intersection of technology and creativity. I build websites, create 2D animations and design visual content, using modern tools and AI-assisted workflows to move from an idea to a finished result.",story2:"With experience across HTML, JavaScript, WordPress, Vyond and AI tools, I approach each project with curiosity and a focus on delivering work that looks professional and communicates clearly.",timeline:[["Started & learned","Built a foundation in web development and creative digital tools."],["Expanded into creativity","Added 2D animation and graphic design to my skill set."],["Client work","Worked with real clients and completed approximately 10 projects/websites."]]},
services:[
{id:"s1",name:"Website Development",short:"Modern, responsive websites focused on structure, usability and a strong first impression.",benefits:["Responsive layouts","Interactive sections","Clean frontend structure","Performance-conscious design"]},
{id:"s2",name:"WordPress Website Development",short:"Professional WordPress websites for businesses, creators and personal brands.",benefits:["Modern page design","Content-ready structure","Responsive experience","Easy future updates"]},
{id:"s3",name:"2D Animation",short:"Clear and engaging animated content using Vyond and AI-assisted creative workflows.",benefits:["Explainer-style animation","Story-driven visuals","Scene and motion design","AI-assisted workflow"]},
{id:"s4",name:"Graphic Design",short:"Creative visual assets with a clean, modern direction and AI-assisted production workflow.",benefits:["Social media visuals","Creative graphics","Visual concepts","Brand-ready assets"]}],
projects:[
{id:"p1",title:"Modern Web Experience",category:"Web Development",description:"Responsive website concept built with HTML and JavaScript.",tools:"HTML, JavaScript",link:"",image:""},
{id:"p2",title:"Business WordPress Website",category:"WordPress",description:"Professional WordPress website concept for a business brand.",tools:"WordPress",link:"",image:""},
{id:"p3",title:"Animated Concept",category:"2D Animation",description:"2D animation concept created with a Vyond + AI workflow.",tools:"Vyond, AI tools",link:"",image:""},
{id:"p4",title:"Creative Visual Concept",category:"Graphic Design",description:"Graphic design concept using modern AI-assisted creative tools.",tools:"AI tools",link:"",image:""}],
achievements:[],testimonials:[],
contact:{heading:"Have an idea? Let's talk.",description:"Tell me what you're working on, what you need, and what you want to achieve. I'll get back to you with the next steps.",intro:"Whether it's a website, WordPress project, animation or creative design, send the details and let's discuss the project."}};
const clone=o=>JSON.parse(JSON.stringify(o));
function get(){try{return {...clone(defaults),...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch{return clone(defaults)}}
function save(d){localStorage.setItem(KEY,JSON.stringify(d));window.dispatchEvent(new Event("aqeelCMSChanged"))}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function setText(s,v){const e=document.querySelector(s);if(e)e.textContent=v}
function apply(d){
document.documentElement.dataset.theme=d.site.theme||"midnight";
document.querySelectorAll("[data-profile-image]").forEach(e=>{if(d.site.profileImage){e.style.backgroundImage=`url("${d.site.profileImage}")`;e.classList.add("has-image");e.innerHTML=""}});
document.querySelectorAll("[data-email-value]").forEach(a=>{a.href="mailto:"+d.site.email;a.textContent=d.site.email});
document.querySelectorAll("[data-tiktok]").forEach(a=>{a.href=d.site.tiktok||"#";if(d.site.tiktok)a.target="_blank"});
const page=document.body.dataset.page;
if(page==="home"){
setText("[data-home-kicker]",d.home.kicker);setText("[data-home-headline]",d.home.headline);setText("[data-home-desc]",d.home.description);
const st=document.querySelector("[data-home-stats]");if(st)st.innerHTML=d.home.stats.map(x=>`<div><strong>${esc(x[0])}</strong><span>${esc(x[1])}</span></div>`).join("");
const sg=document.querySelector("[data-home-services]");if(sg)sg.innerHTML=d.services.map((s,i)=>`<article class="service-card reveal"><div class="icon">${["⌘","W","◉","✦"][i]||"✦"}</div><span>0${i+1}</span><h3>${esc(s.name)}</h3><p>${esc(s.short)}</p><a href="services.html">Explore service →</a></article>`).join("");
const pg=document.querySelector("[data-featured-projects]");if(pg)pg.innerHTML=d.projects.slice(0,4).map(projectHTML).join("");
const tg=document.querySelector("[data-testimonials]");if(tg)tg.innerHTML=d.testimonials.length?d.testimonials.map(t=>`<article class="quote-card"><p>“${esc(t.quote)}”</p><strong>${esc(t.name)}</strong><span>${esc(t.role||"Client")}</span></article>`).join(""):`<div class="empty-card"><h3>Testimonials coming soon.</h3><p>Real client testimonials will appear here after you add them from the Admin Panel.</p></div>`;
}
if(page==="portfolio"){const g=document.querySelector("[data-project-grid]");if(g)g.innerHTML=d.projects.map(projectHTML).join("")}
if(page==="services"){const g=document.querySelector("[data-services-grid]");if(g)g.innerHTML=d.services.map((s,i)=>`<article class="service-full reveal"><div class="kicker">${String(i+1).padStart(2,"0")} · SERVICE</div><h3>${esc(s.name)}</h3><p>${esc(s.short)}</p><ul>${s.benefits.map(b=>`<li>${esc(b)}</li>`).join("")}</ul><a class="btn ghost" href="contact.html">Get a Quote ↗</a></article>`).join("")}
if(page==="about"){setText("[data-about-headline]",d.about.headline);setText("[data-about-intro]",d.about.intro);setText("[data-about-mindset]",d.about.mindset);setText("[data-about-story1]",d.about.story1);setText("[data-about-story2]",d.about.story2);const t=document.querySelector("[data-about-timeline]");if(t)t.innerHTML=d.about.timeline.map(x=>`<div><strong>${esc(x[0])}</strong><p>${esc(x[1])}</p></div>`).join("")}
if(page==="achievements"){const g=document.querySelector("[data-achievement-grid]");if(g)g.innerHTML=d.achievements.length?d.achievements.map(a=>`<article class="achievement-card reveal"><span class="kicker">${esc(a.year||"ACHIEVEMENT")}</span><h3>${esc(a.title)}</h3><p>${esc(a.description)}</p></article>`).join(""):`<div class="empty-card"><h3>Your real achievements will appear here.</h3><p>Add genuine achievements through the Admin Panel.</p><a class="btn primary" href="admin.html">Open Admin Panel ↗</a></div>`}
if(page==="contact"){setText("[data-contact-heading]",d.contact.heading);setText("[data-contact-desc]",d.contact.description);setText("[data-contact-intro]",d.contact.intro);document.querySelectorAll("[data-tiktok-value]").forEach(a=>{a.href=d.site.tiktok||"#";a.textContent=d.site.tiktok||"Add your TikTok link"})}
}
function projectHTML(p,i){const cls=i%3===0?"art-web":i%3===1?"art-wp":"art-motion";return `<article class="project-card portfolio-item reveal" data-category="${esc(p.category)}"><div class="project-art ${cls}" ${p.image?`style="background-image:url('${p.image}');background-size:cover;background-position:center"`:""}><span>${String(i+1).padStart(2,"0")}</span><b>${esc(p.category)}</b></div><div class="project-info"><div><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p><small>${esc(p.tools||"")}</small></div>${p.link?`<a href="${esc(p.link)}" target="_blank" rel="noopener">↗</a>`:"<span>↗</span>"}</div></article>`}
window.AqeelCMS={get,save,defaults:clone(defaults),esc,apply};
document.addEventListener("DOMContentLoaded",()=>apply(get()));window.addEventListener("aqeelCMSChanged",()=>apply(get()));
})();