const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      entry.target.querySelectorAll(".skill-bar span").forEach(s => s.style.width = s.dataset.width || "0%");
      observer.unobserve(entry.target);
    }
  });
}, {threshold:.12});
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

const menu = document.querySelector(".menu-btn");
const nav = document.querySelector(".nav nav");
if(menu && nav){
  menu.addEventListener("click",()=>{
    nav.style.display = nav.style.display==="flex" ? "none" : "flex";
    nav.style.flexDirection="column"; nav.style.position="absolute"; nav.style.top="70px"; nav.style.right="0";
    nav.style.background="#0b0e1a"; nav.style.padding="18px"; nav.style.border="1px solid rgba(255,255,255,.1)"; nav.style.borderRadius="14px";
  });
}

document.querySelectorAll("[data-filter]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll("[data-filter]").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    const filter=btn.dataset.filter;
    document.querySelectorAll(".portfolio-item").forEach(item=>{
      item.classList.toggle("hide", filter!=="all" && item.dataset.category!==filter);
    });
  });
});

const form=document.querySelector("#contactForm");
if(form) form.addEventListener("submit",e=>{
  e.preventDefault();
  const msg=document.querySelector("#formMessage");
  if(msg){msg.textContent="Thanks! Your message was captured in this demo. Connect a real email/backend before publishing.";msg.style.display="block";}
  form.reset();
});

/* ===== Local Admin Dashboard ===== */
const adminLoginForm=document.querySelector("#adminLoginForm");
const loginBox=document.querySelector(".admin-login");
const dashboard=document.querySelector(".admin-dashboard");
const statusBox=document.querySelector("#saveStatus");

function showAdminStatus(message){
  if(statusBox){statusBox.textContent=message;statusBox.style.display="block";setTimeout(()=>statusBox.style.display="none",2500);}
}
function loadAdminData(){
  const home=JSON.parse(localStorage.getItem("aqeelHome")||"{}");
  const contact=JSON.parse(localStorage.getItem("aqeelContact")||"{}");
  const h=document.querySelector("#adminHeadline"), d=document.querySelector("#adminHeroDesc");
  const e=document.querySelector("#adminEmail"), t=document.querySelector("#adminTikTok");
  if(h) h.value=home.headline || "Ideas into digital experiences.";
  if(d) d.value=home.description || "I'm Aqeel Mehmood — a Web Developer, 2D Animator and Graphic Designer creating modern digital work.";
  if(e) e.value=contact.email || "your-email@example.com";
  if(t) t.value=contact.tiktok || "";
  renderProjects();
}
function renderProjects(){
  const box=document.querySelector("#projectList"); if(!box) return;
  const projects=JSON.parse(localStorage.getItem("aqeelProjects")||"[]");
  box.innerHTML=projects.length ? projects.map((p,i)=>`<div style="border-top:1px solid rgba(255,255,255,.08);padding:10px 0;display:flex;justify-content:space-between;gap:10px"><span><strong>${escapeHtml(p.title)}</strong><br><small style="color:#737b90">${escapeHtml(p.category)}</small></span><button type="button" class="logout delete-project" data-index="${i}" style="margin:0;padding:6px 9px">Delete</button></div>`).join("") : '<p style="color:#737b90;font-size:11px">No custom projects added yet.</p>';
  box.querySelectorAll(".delete-project").forEach(btn=>btn.addEventListener("click",()=>{
    const arr=JSON.parse(localStorage.getItem("aqeelProjects")||"[]"); arr.splice(Number(btn.dataset.index),1); localStorage.setItem("aqeelProjects",JSON.stringify(arr)); renderProjects(); showAdminStatus("Project deleted.");
  }));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

if(adminLoginForm){
  if(sessionStorage.getItem("aqeelAdminLoggedIn")==="true"){loginBox.style.display="none";dashboard.style.display="block";loadAdminData();}
  adminLoginForm.addEventListener("submit",e=>{
    e.preventDefault();
    const u=document.querySelector("#adminUser").value.trim(), p=document.querySelector("#adminPass").value;
    if(u==="admin" && p==="Aqeel@2026"){
      sessionStorage.setItem("aqeelAdminLoggedIn","true");
      loginBox.style.display="none"; dashboard.style.display="block"; loadAdminData();
    } else document.querySelector("#loginError").textContent="Invalid username or password.";
  });
}
document.querySelector("#saveHome")?.addEventListener("click",()=>{
  localStorage.setItem("aqeelHome",JSON.stringify({headline:document.querySelector("#adminHeadline").value,description:document.querySelector("#adminHeroDesc").value}));
  showAdminStatus("Home content saved in this browser.");
});
document.querySelector("#saveContact")?.addEventListener("click",()=>{
  localStorage.setItem("aqeelContact",JSON.stringify({email:document.querySelector("#adminEmail").value,tiktok:document.querySelector("#adminTikTok").value}));
  showAdminStatus("Contact details saved in this browser.");
});
document.querySelector("#addProject")?.addEventListener("click",()=>{
  const title=document.querySelector("#projectTitle").value.trim(), category=document.querySelector("#projectCategory").value, desc=document.querySelector("#projectDesc").value.trim();
  if(!title){showAdminStatus("Please enter a project title.");return;}
  const arr=JSON.parse(localStorage.getItem("aqeelProjects")||"[]"); arr.push({title,category,description:desc}); localStorage.setItem("aqeelProjects",JSON.stringify(arr));
  document.querySelector("#projectTitle").value=""; document.querySelector("#projectDesc").value=""; renderProjects(); showAdminStatus("Project added.");
});
document.querySelector("#saveImage")?.addEventListener("click",()=>{
  const input=document.querySelector("#profileImage");
  if(!input.files?.[0]){showAdminStatus("Choose an image first.");return;}
  const reader=new FileReader(); reader.onload=()=>{try{localStorage.setItem("aqeelProfileImage",reader.result);document.querySelector("#imageStatus").textContent="Profile image saved in this browser.";}catch{document.querySelector("#imageStatus").textContent="Image is too large for browser storage; use a real backend for production."}}; reader.readAsDataURL(input.files[0]);
});
document.querySelector("#logout")?.addEventListener("click",()=>{sessionStorage.removeItem("aqeelAdminLoggedIn");location.reload();});
